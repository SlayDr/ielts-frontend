/* Essay History Page Styles */

@import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Libre+Baskerville:wght@400;700&display=swap');

.essay-history {
  min-height: 100vh;
  background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
  font-family: 'DM Sans', -apple-system, BlinkMacSystemFont, sans-serif;
  padding-bottom: 4rem;
}

/* Header */
.history-header {
  background: linear-gradient(135deg, #1e3a5f 0%, #2d5a87 50%, #1e3a5f 100%);
  padding: 2rem 1.5rem 3rem;
  position: relative;
  overflow: hidden;
}

.history-header::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.03'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E");
  opacity: 0.5;
}

.header-content {
  max-width: 1200px;
  margin: 0 auto;
  position: relative;
  z-index: 1;
}

.back-btn {
  background: rgba(255, 255, 255, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.2);
  color: white;
  padding: 0.5rem 1rem;
  border-radius: 8px;
  font-size: 0.9rem;
  cursor: pointer;
  transition: all 0.2s ease;
  margin-bottom: 1rem;
  font-family: inherit;
}

.back-btn:hover {
  background: rgba(255, 255, 255, 0.2);
  transform: translateX(-3px);
}

.history-header h1 {
  font-family: 'Libre Baskerville', Georgia, serif;
  font-size: 2.5rem;
  font-weight: 700;
  color: white;
  margin: 0 0 0.5rem;
  letter-spacing: -0.02em;
}

.subtitle {
  color: rgba(255, 255, 255, 0.8);
  font-size: 1.1rem;
  margin: 0;
}

/* Stats Section */
.stats-section {
  max-width: 1200px;
  margin: -2rem auto 2rem;
  padding: 0 1.5rem;
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 1rem;
  position: relative;
  z-index: 2;
}

.stat-card {
  background: white;
  border-radius: 16px;
  padding: 1.5rem;
  display: flex;
  align-items: center;
  gap: 1rem;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
  transition: transform 0.2s ease, box-shadow 0.2s ease;
}

.stat-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 30px rgba(0, 0, 0, 0.12);
}

.stat-icon {
  font-size: 2rem;
  width: 56px;
  height: 56px;
  background: linear-gradient(135deg, #e8f4fd 0%, #d0e8f7 100%);
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.stat-info {
  display: flex;
  flex-direction: column;
}

.stat-value {
  font-size: 1.75rem;
  font-weight: 700;
  color: #1e3a5f;
  line-height: 1.2;
}

.stat-label {
  font-size: 0.85rem;
  color: #64748b;
  font-weight: 500;
}

/* Filters Section */
.filters-section {
  max-width: 1200px;
  margin: 0 auto 1.5rem;
  padding: 0 1.5rem;
  display: flex;
  gap: 1rem;
  flex-wrap: wrap;
}

.filter-group {
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

.filter-group label {
  font-size: 0.9rem;
  color: #64748b;
  font-weight: 500;
}

.filter-group select {
  padding: 0.6rem 2rem 0.6rem 1rem;
  border: 2px solid #e2e8f0;
  border-radius: 10px;
  font-size: 0.9rem;
  font-family: inherit;
  background: white;
  cursor: pointer;
  transition: border-color 0.2s ease;
  appearance: none;
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%2364748b' d='M6 8L1 3h10z'/%3E%3C/svg%3E");
  background-repeat: no-repeat;
  background-position: right 0.75rem center;
}

.filter-group select:focus {
  outline: none;
  border-color: #2d5a87;
}

/* Essays Section */
.essays-section {
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 1.5rem;
}

.essays-list {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

/* Essay Card */
.essay-card {
  background: white;
  border-radius: 16px;
  overflow: hidden;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.06);
  transition: all 0.3s ease;
  border: 1px solid transparent;
}

.essay-card:hover {
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
}

.essay-card.expanded {
  border-color: #2d5a87;
}

.essay-card-header {
  padding: 1.25rem 1.5rem;
  display: flex;
  justify-content: space-between;
  align-items: center;
  cursor: pointer;
  gap: 1rem;
}

.essay-main-info {
  flex: 1;
  min-width: 0;
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.task-type-badge {
  display: inline-block;
  padding: 0.25rem 0.75rem;
  background: linear-gradient(135deg, #e8f4fd 0%, #d0e8f7 100%);
  color: #1e3a5f;
  font-size: 0.75rem;
  font-weight: 600;
  border-radius: 20px;
  width: fit-content;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}

.essay-topic {
  font-size: 1rem;
  font-weight: 600;
  color: #1e293b;
  margin: 0;
  line-height: 1.4;
}

.essay-date {
  font-size: 0.85rem;
  color: #94a3b8;
}

.essay-score-section {
  display: flex;
  align-items: center;
  gap: 1rem;
  flex-shrink: 0;
}

.score-badge {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 0.5rem 1rem;
  border-radius: 12px;
  min-width: 70px;
}

.score-label {
  font-size: 0.65rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.1em;
  opacity: 0.8;
}

.score-value {
  font-size: 1.5rem;
  font-weight: 700;
  line-height: 1.2;
}

.score-high {
  background: linear-gradient(135deg, #dcfce7 0%, #bbf7d0 100%);
  color: #166534;
}

.score-medium {
  background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%);
  color: #92400e;
}

.score-low {
  background: linear-gradient(135deg, #fee2e2 0%, #fecaca 100%);
  color: #991b1b;
}

.score-pending {
  background: linear-gradient(135deg, #f1f5f9 0%, #e2e8f0 100%);
  color: #64748b;
}

.expand-icon {
  font-size: 0.75rem;
  color: #94a3b8;
  transition: transform 0.3s ease;
}

.essay-card.expanded .expand-icon {
  transform: rotate(180deg);
}

/* Essay Card Body (Expanded) */
.essay-card-body {
  padding: 0 1.5rem 1.5rem;
  border-top: 1px solid #f1f5f9;
  animation: slideDown 0.3s ease;
}

@keyframes slideDown {
  from {
    opacity: 0;
    transform: translateY(-10px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.essay-content-section,
.feedback-section,
.rewrite-section {
  margin-top: 1.5rem;
}

.essay-content-section h4,
.feedback-section h4,
.rewrite-section h4 {
  font-size: 0.9rem;
  font-weight: 600;
  color: #1e3a5f;
  margin: 0 0 0.75rem;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}

.essay-text,
.rewrite-text {
  font-size: 0.95rem;
  line-height: 1.7;
  color: #374151;
  background: #f8fafc;
  padding: 1.25rem;
  border-radius: 12px;
  white-space: pre-wrap;
  border-left: 4px solid #2d5a87;
}

.rewrite-text {
  border-left-color: #10b981;
  background: #f0fdf4;
}

.word-count {
  margin-top: 0.75rem;
  font-size: 0.85rem;
  color: #64748b;
  font-weight: 500;
}

/* Feedback Content */
.feedback-content {
  background: #fffbeb;
  border-radius: 12px;
  padding: 1.25rem;
  border-left: 4px solid #f59e0b;
}

.feedback-category {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0.5rem 0;
  border-bottom: 1px solid rgba(245, 158, 11, 0.2);
}

.feedback-category:last-of-type {
  border-bottom: none;
}

.category-label {
  font-size: 0.9rem;
  color: #92400e;
  font-weight: 500;
}

.category-score {
  font-size: 1.1rem;
  font-weight: 700;
  color: #92400e;
}

.feedback-comments {
  margin-top: 1rem;
  padding-top: 1rem;
  border-top: 1px solid rgba(245, 158, 11, 0.2);
}

.feedback-comments h5 {
  font-size: 0.85rem;
  font-weight: 600;
  color: #92400e;
  margin: 0 0 0.5rem;
}

.feedback-comments p {
  font-size: 0.9rem;
  line-height: 1.6;
  color: #78350f;
  margin: 0;
}

/* Essay Actions */
.essay-actions {
  margin-top: 1.5rem;
  display: flex;
  gap: 0.75rem;
  flex-wrap: wrap;
}

.action-btn {
  padding: 0.75rem 1.25rem;
  border-radius: 10px;
  font-size: 0.9rem;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s ease;
  font-family: inherit;
  border: none;
}

.practice-again {
  background: linear-gradient(135deg, #2d5a87 0%, #1e3a5f 100%);
  color: white;
}

.practice-again:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(45, 90, 135, 0.3);
}

/* Empty State */
.empty-state {
  text-align: center;
  padding: 4rem 2rem;
  background: white;
  border-radius: 20px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.06);
}

.empty-icon {
  font-size: 4rem;
  margin-bottom: 1rem;
}

.empty-state h2 {
  font-family: 'Libre Baskerville', Georgia, serif;
  font-size: 1.5rem;
  color: #1e3a5f;
  margin: 0 0 0.5rem;
}

.empty-state p {
  color: #64748b;
  margin: 0 0 1.5rem;
}

.start-btn {
  background: linear-gradient(135deg, #2d5a87 0%, #1e3a5f 100%);
  color: white;
  border: none;
  padding: 1rem 2rem;
  border-radius: 12px;
  font-size: 1rem;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s ease;
  font-family: inherit;
}

.start-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 6px 20px rgba(45, 90, 135, 0.3);
}

/* Loading State */
.loading-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  min-height: 60vh;
  gap: 1rem;
}

.loading-spinner {
  width: 50px;
  height: 50px;
  border: 4px solid #e2e8f0;
  border-top-color: #2d5a87;
  border-radius: 50%;
  animation: spin 1s linear infinite;
}

@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}

.loading-container p {
  color: #64748b;
  font-size: 1rem;
}

/* Error State */
.error-container {
  text-align: center;
  padding: 4rem 2rem;
  max-width: 400px;
  margin: 4rem auto;
}

.error-icon {
  font-size: 3rem;
  margin-bottom: 1rem;
}

.error-container h2 {
  font-size: 1.25rem;
  color: #991b1b;
  margin: 0 0 0.5rem;
}

.error-container p {
  color: #64748b;
  margin: 0 0 1.5rem;
}

.retry-btn {
  background: #fee2e2;
  color: #991b1b;
  border: none;
  padding: 0.75rem 1.5rem;
  border-radius: 10px;
  font-size: 0.95rem;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s ease;
  font-family: inherit;
}

.retry-btn:hover {
  background: #fecaca;
}

/* Responsive Design */
@media (max-width: 768px) {
  .history-header {
    padding: 1.5rem 1rem 2.5rem;
  }

  .history-header h1 {
    font-size: 1.75rem;
  }

  .stats-section {
    margin-top: -1.5rem;
    padding: 0 1rem;
  }

  .stat-card {
    padding: 1rem;
  }

  .stat-value {
    font-size: 1.5rem;
  }

  .filters-section {
    padding: 0 1rem;
    flex-direction: column;
    align-items: stretch;
  }

  .filter-group {
    flex-direction: column;
    align-items: stretch;
  }

  .filter-group select {
    width: 100%;
  }

  .essays-section {
    padding: 0 1rem;
  }

  .essay-card-header {
    flex-direction: column;
    align-items: stretch;
    gap: 1rem;
  }

  .essay-score-section {
    justify-content: space-between;
  }

  .essay-card-body {
    padding: 0 1rem 1rem;
  }

  .essay-text,
  .rewrite-text,
  .feedback-content {
    padding: 1rem;
  }
}
```

---

## Now you have both files:
```
src/
├── pages/
│   ├── EssayHistory.jsx   ✅
│   ├── EssayHistory.css   ✅